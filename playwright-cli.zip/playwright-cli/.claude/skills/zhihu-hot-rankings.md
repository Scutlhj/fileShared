---
name: zhihu-hot-rankings
description: 抓取知乎热榜前 N 条标题和热度，输出 JSON 并截图。
allowed-tools: Bash(playwright-cli:*)
---

# 知乎热榜抓取

## 前置条件

- 登录态已保存到 `zhihu-auth.json`（通过 `state-save` 生成）
- 运行环境已安装 playwright-cli
- 知乎热榜需要登录才能访问

## 命令序列

```bash
# 1. 打开知乎热榜（复用同一 session 名，方便后续命令操作）
playwright-cli open https://www.zhihu.com/hot -s=zhihu-hot

# 2. 加载已保存的登录态，跳过登录流程
playwright-cli state-load zhihu-auth.json -s=zhihu-hot

# 3. 刷新页面：知乎会先跳登录页再自动恢复，reload 后稳定进入热榜
playwright-cli reload -s=zhihu-hot

# 4. 读取快照，确认页面结构未变
playwright-cli snapshot -s=zhihu-hot --filename=zhihu-hot.yml

# 5. 提取前 10 条热榜数据并保存为 JSON（eval 顶层不能写 return/const，用 IIFE 包一层）
playwright-cli --raw eval '
  (() => {
    const items = [...document.querySelectorAll("section.HotItem")].slice(0, 10);
    return {
      date: new Date().toISOString(),
      items: items.map((el, index) => ({
        rank: index + 1,
        title: el.querySelector(".HotItem-title")?.innerText?.trim() || "",
        hot: el.querySelector(".HotItem-metrics")?.innerText?.replace(/\n.*$/s, "").trim() || ""
      }))
    };
  })()
' -s=zhihu-hot > zhihu-hot.json

# 6. 截图留档
playwright-cli screenshot -s=zhihu-hot --filename=zhihu-hot.png

# 7. 关闭会话，释放浏览器进程
playwright-cli close -s=zhihu-hot
```

## 关键规则

- **登录态文件**：固定使用 `zhihu-auth.json`。如果 `reload` 后 URL 仍包含 `signin`，说明登录态已过期，需要重新手动登录并保存。
- **热榜容器选择器**：`section.HotItem`（比 `.HotItem` 更精确，避免匹配到子元素）。
- **标题选择器**：`.HotItem-title`。
- **热度选择器**：`.HotItem-metrics`，原始文本包含 `"\n​\n分享"`，需用 `replace(/\n.*$/s, "")` 清理。
- **输出格式**：`zhihu-hot.json`，结构为 `{ date: ISO字符串, items: [{ rank, title, hot }] }`。
- **截图文件名**：`zhihu-hot.png`。

## 失败处理

- 如果 `zhihu-hot.json` 为空或 `items` 为空数组：页面结构可能已改版，需要重新探索选择器。
- 如果 `reload` 后仍在登录页：登录态过期，重新执行登录流程并保存新的 `zhihu-auth.json`。
- 如果频繁运行被风控：增加随机 sleep、降低执行频率、确保使用 `--persistent` 保存的真实登录态。
