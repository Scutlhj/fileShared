# Playwright CLI + Skill：AI 浏览器自动化的实践

浏览器自动化在 AI Agent 场景下的需求越来越大。`@playwright/cli` 是微软 Playwright 团队在 2026 年发布的命令行界面（CLI），主打 Coding Agent 场景：把 Playwright 的浏览器能力封装成 Shell 命令，让 AI 通过更短的指令、更少的上下文完成自动化。本文介绍它的安装使用、核心命令、与 MCP 的差异、工具选型，以及和 Claude Code 配合的示例。

---

## 一、安装

```bash
npm install -g @playwright/cli@latest
playwright-cli --version
playwright-cli install --skills
```

- `npm install -g @playwright/cli@latest`：安装 CLI 本身。
- `playwright-cli install --skills`：初始化 workspace、准备浏览器等运行时依赖，并安装 Skill。
- 如果只想单独安装浏览器，可用 `playwright-cli install-browser [chrome|firefox|webkit|msedge]`；不指定浏览器时默认安装 Chromium。

装完之后 `playwright-cli` 即可使用。建议先跑一遍 `--help` 确认命令版本：

```bash
playwright-cli --help
playwright-cli open --help
```

---

## 二、CLI 命令详解

以下列出日常最高频的命令，完整命令列表可通过 `playwright-cli --help` 查看。

### 全局用法

CLI 采用守护进程架构，浏览器进程常驻，不同会话在逻辑上隔离。常用写法：

```bash
playwright-cli -s=<session> <command> [args] [options]
```

`-s=<session>`（简写 `-s`）指定会话名。

### `open`：打开页面

```bash
playwright-cli open [url] [options]
```

关键参数：

| 参数                   | 含义                                         |
| ---------------------- | -------------------------------------------- |
| `--headed`             | 有头模式，显示浏览器窗口                     |
| `-s=<session>`         | 会话名称，后续命令通过这个名字操作同一浏览器 |
| `--persistent`         | 持久化会话，Cookie 和 LocalStorage 保留到磁盘 |
| `--profile=<dir>`      | 指定持久化用户数据目录                       |
| `--browser=<name>`     | 指定浏览器：chrome / firefox / webkit / msedge |

```bash
playwright-cli open https://www.zhihu.com --headed -s=zhihu
playwright-cli open https://www.zhihu.com --headed -s=zhihu --persistent
```

加上 `--persistent` 后，用户数据目录被保留到磁盘，下次打开同一会话时登录态还在。

### `snapshot`：获取页面快照

`snapshot` 是最核心的命令，获取当前页面的**可访问性树（a11y tree）**。CLI 在终端会用 Markdown 简要包装输出（显示 `### Page` 和 `### Snapshot`），真正的快照内容会保存到 `.playwright-cli/page-<timestamp>.yml`，是一种**类 YAML 的层级文本格式**，不是标准 Markdown 或 YAML。

```bash
playwright-cli snapshot -s=<session> [--filename=<file>]
```

输出示例（简化）：

```yaml
### Page
- Page URL: https://www.zhihu.com/
- Page Title: 知乎 - 有问题，就会有答案

### Snapshot
- [Snapshot](.playwright-cli/page-2026-07-09T18-40-08-851Z.yml)
```

快照文件 `.playwright-cli/page-*.yml` 的实际内容大概长这样（层级缩进表示 DOM 嵌套）：

```text
- generic [active] [ref=f1e1]:
  - link "欢迎进入 知乎 - 有问题，就会有答案" [ref=f1e2] [cursor=pointer]:
    - /url: https://www.zhihu.com/
  - main [ref=f1e5]:
    - textbox "搜索" [ref=f1e45]:
      - /placeholder: 手机号
    - button "登录/注册" [ref=f1e54] [cursor=pointer]
```

每个可交互元素分配一个 `ref`（如 `f1e2`、`f1e54`），后续交互都基于这些引用。这是 CLI 省 Token 的关键——AI 只需要知道 `f1e45` 是搜索框，不需要处理整个 DOM。

### 元素交互

```bash
# 鼠标点击（可选 left/right/middle，默认 left）
playwright-cli click <ref> [left|right|middle] -s=<session>

# 键盘输入：在当前焦点元素输入文本
playwright-cli type "文本" -s=<session>

# 填充指定元素并清空原有内容；--submit 会在填充后按 Enter
playwright-cli fill <ref> "文本" -s=<session> [--submit]

# 按键操作
playwright-cli press Enter -s=<session>
playwright-cli press "Control+a" -s=<session>

# 复选框/单选框与悬停
playwright-cli check <ref> -s=<session>
playwright-cli hover <ref> -s=<session>
```

- `type` 在当前焦点元素输入。
- `fill` 直接操作指定元素并清空原有内容；加 `--submit` 会在填充后按 Enter。
- `click` 的按键是位置参数，例如 `click e3 right`。
- `press` 支持单键和组合键。

### 页面操作

```bash
# 截图与 PDF 导出
playwright-cli screenshot -s=<session> [--filename=<file>] [--full-page]
playwright-cli pdf -s=<session> [--filename=<file>]

# 在页面上下文执行 JS（返回结果会被序列化）
playwright-cli eval "document.title" -s=<session>
playwright-cli eval "el => el.textContent" <ref> -s=<session>

# 查看浏览器控制台日志（默认全部，可指定级别）
playwright-cli console -s=<session> [verbose|info|warning|error]
```

### 导航、标签页与 attach

```bash
# 页面导航
playwright-cli goto https://example.com -s=<session>
playwright-cli reload -s=<session>
playwright-cli go-back -s=<session>
playwright-cli go-forward -s=<session>

# 标签页管理
playwright-cli tab-list -s=<session>
playwright-cli tab-new [url] -s=<session>
playwright-cli tab-select 0 -s=<session>
playwright-cli tab-close [index] -s=<session>

# 连接到已运行的 Chrome/Edge（通过 CDP）
playwright-cli attach --cdp=chrome
playwright-cli attach --cdp=http://localhost:9222
```

### 会话与存储

```bash
# 保存/恢复登录态（cookies、localStorage 等）
playwright-cli state-save [auth.json] -s=<session>
playwright-cli state-load auth.json -s=<session>

# Cookie 与会话列表
playwright-cli cookie-list -s=<session>
playwright-cli list

# 关闭会话
playwright-cli close -s=<session>
playwright-cli close-all
```

`state-save` / `state-load` 用于保存和恢复登录态。手动登录一次后 save，后续脚本 load 即可跳过登录流程。

### Tracing

```bash
# 开始/停止录制 trace（包含截图、DOM、网络请求）
playwright-cli tracing-start -s=<session>
# ... 执行操作 ...
playwright-cli tracing-stop -s=<session> [trace.zip]
```

Tracing 记录每一步的截图、DOM 快照、网络请求，可用 Playwright Trace Viewer 打开 `trace.zip` 逐帧回放，定位问题很快。

---

## 三、CLI vs MCP：省 Token 的原因与选型

### 3.1 为什么 CLI 比 MCP 省 Token

让 AI 操作浏览器，主流方案之一是 Playwright MCP。MCP 把浏览器能力封装成一组工具函数，LLM 通过 JSON-RPC 调用。每次操作后，完整的可访问性树（a11y tree）会自动注入 LLM 上下文——这是协议层面的设计，LLM 需要最新页面状态才能决定下一步。一棵 a11y tree 通常几十 KB，多步操作后上下文会被页面元数据占满。

Playwright CLI 走的是另一条路：**把同样的 Playwright 能力暴露为 Shell 命令**，页面状态由 AI 主动读取，而不是每步自动注入。CLI 没有大段工具 Schema，命令就是普通字符串，Agent 按需调用、按需查看快照。

> 注意：CLI 不是 MCP 的“替代协议”，而是同一套 Playwright 能力的不同界面。官方 README 的说法是“CLI interface into Playwright”。

### 3.2 MCP Tool Search 的作用和局限

Claude Code 在 2026 年初推出了 MCP Tool Search 机制（也称懒加载）——工具 Schema 不再全部预加载，而是按需搜索动态加载。这缓解了工具定义本身的 Token 消耗，但改变不了每次操作返回 a11y tree 的设计。

MCP Tool Search 优化的是“工具定义”的加载方式：会话启动时只创建一个轻量注册表（工具名 + 简短描述），需要时再动态加载完整定义。配置多个 MCP Server 时，初始上下文消耗会显著降低。

但它解决不了浏览器自动化中另一个更大的 Token 消耗来源：**每次操作返回的页面状态**。

Playwright MCP 的工作流程：

```
LLM 输出 tool_call → MCP Server 执行 → 返回完整 a11y tree → 自动注入上下文 → LLM 再次思考
```

这一步的 a11y tree 是协议强制返回的，懒加载机制不涉及这里。十次点击就是十棵完整的树注入上下文。

Playwright CLI 的工作流程：

```
LLM 写 Shell 命令 → 终端执行 → 结果写磁盘/stdout → LLM 按需 Read → 再次思考
```

页面状态不会自动进入上下文，AI 只有在显式读取 snapshot 时才消费这部分 Token。

### 3.3 Token 消耗的第三方参考

社区/第三方对同一浏览器自动化任务在 MCP 和 CLI 模式下的 Token 消耗做过一些对比，参考值如下：

| 工具           | 典型任务 Token（估算） | 说明                     |
| -------------- | ---------------------- | ------------------------ |
| Playwright MCP | ~114k                  | 第三方博客/社区估算      |
| Playwright CLI | ~27k                   | 第三方博客/社区估算      |

第三方基准测试通常给的是“典型任务”的平均 Token，但长会话里的差距会进一步拉大。

原因是 MCP 的协议设计：每次工具调用后，完整的页面状态会自动返回并注入上下文。十步操作就是十棵完整的 a11y tree；二十步、五十步后，上下文被页面元数据占满，模型能看到的“有效思考空间”越来越少。测试数据显示，复杂长会话里 MCP 的 Token 消耗可能达到 CLI 的数倍甚至十倍以上。

CLI 不一样：snapshot 写到磁盘，只有 AI 显式读取时才进上下文。页面状态不会随每次操作膨胀，长会话的成本曲线更平缓。

所以选型时不仅要看单次任务，还要看**会话长度和迭代次数**：

- 临时 3-5 步的查询，MCP 和 CLI 差距不大。
- 10 步以上的多轮操作、每天重复跑的自动化，CLI 的优势会非常明显。

### 3.4 差异总结

| 维度           | Playwright MCP                          | Playwright CLI              |
| -------------- | --------------------------------------- | --------------------------- |
| 工具 Schema    | 懒加载（Tool Search），少量初始 tokens  | 无 Schema，命令即字符串     |
| 操作返回值     | 每步自动注入完整 a11y tree              | 按需读取 snapshot           |
| 典型任务 Token | ~114k（第三方估算）                     | ~27k（第三方估算）          |
| 调用方式       | LLM 输出结构化参数 → JSON-RPC           | AI 写 Shell 命令 → 终端执行 |
| 上下文管理     | 被动接收页面状态                        | 主动控制何时读取            |
| 运行环境       | 任何 MCP 宿主                           | 需文件系统 + Shell          |

### 3.5 与其他工具的关系

**Chrome DevTools MCP**：通常被认为是 Google 相关团队基于 Chrome DevTools Protocol（CDP）维护的方案（具体维护主体请以官方仓库为准）。它的核心能力不是“自动化操作”，而是**诊断和调试**：性能追踪、Lighthouse 审计、网络请求查看、V8 堆内存快照、Console 日志等。

它与 Playwright 方案最关键的区别是 **DevTools MCP 可以 attach 到用户当前正在运行的 Chrome 实例**，复用已登录会话、访问 localhost 开发服务器、操作 Electron 应用（如 VS Code、Slack、Discord）。Playwright CLI 本身也支持通过 `attach --cdp` 连接到已有浏览器，但 DevTools MCP 在诊断工具链和原生 Chrome 集成上更完整。

**两者的关系是互补的**：Playwright MCP 负责“开车”（页面导航、点击、填表），DevTools MCP 负责“修车”（性能分析、网络排查、内存诊断）。Claude Code 里可以同时配置两个，自动化用 Playwright CLI，遇到性能问题或需要 attach 到现有 Chrome 时切 DevTools MCP。

### 3.7 选型建议

| 需求                                  | 推荐方案                          |
| ------------------------------------- | --------------------------------- |
| Claude Code / Cursor 内嵌浏览器自动化 | Playwright CLI（最低 Token）      |
| 沙箱聊天界面                          | Playwright MCP                    |
| 需要复用已登录 Chrome / localhost     | Chrome DevTools MCP               |
| 性能诊断、Lighthouse 审计             | Chrome DevTools MCP               |

---

## 四、示例：知乎热榜监测 + Skill 三段式降本

这个示例会完整介绍 **AI 探索 → 提炼 Skill → 固化脚本** 的三段式，以知乎热榜监测为例。

### 4.1 场景与目标

任务：打开知乎热榜，抓取前 10 条热榜标题和热度值，截图留档，并导出为 JSON 供后续分析。

这个场景比“搜索后截图”更能体现 CLI 在 AI Agent 中的价值：页面数据需要被提取成结构化格式，而不是只看一眼。它也适合做成定时任务，每天跑一次，追踪热榜趋势。

> 注意：知乎热榜现在需要登录才能访问。下面的流程假设你已经按 4.2 节保存了登录态 `zhihu-auth.json`。

### 4.2 前置准备：保存登录态

先用 `--persistent` 模式手动登录一次，把登录态保存下来，后续脚本直接复用：

```bash
# 1. 打开知乎登录页
playwright-cli open https://www.zhihu.com/signin --headed -s=zhihu-auth --persistent

# 2. 在弹出的浏览器窗口中手动完成登录（验证码环节需要人工处理）

# 3. 保存登录态
playwright-cli state-save zhihu-auth.json -s=zhihu-auth

# 4. 关闭会话
playwright-cli close -s=zhihu-auth
```

`zhihu-auth.json` 后续会被所有抓取脚本复用，跳过登录流程。

### 4.3 第一段：AI 探索

你对着 Claude Code 说：

> “帮我用 playwright-cli 打开知乎热榜，抓前 10 条热榜的标题和热度，保存成 JSON 再截个图。”

AI 开始尝试。第一次它可能直接打开 `https://www.zhihu.com/hot`，发现被重定向到登录页；你告诉它登录态已存在 `zhihu-auth.json` 后，它加上 `state-load` 重试。

几番试错后，AI 最终走通的命令序列大致如下：

```bash
# 1. 打开知乎热榜（无头模式，session 名为 zhihu-hot）
playwright-cli open https://www.zhihu.com/hot -s=zhihu-hot

# 2. 加载已保存的登录态，跳过手动登录
playwright-cli state-load zhihu-auth.json -s=zhihu-hot

# 3. 知乎会先跳到登录页再自动恢复，刷新一次确保进入热榜
playwright-cli reload -s=zhihu-hot

# 4. 读取快照，确认页面已加载并观察元素 ref
playwright-cli snapshot -s=zhihu-hot --filename=zhihu-hot.yml

# 5. 用 eval 提取前 10 条热榜数据（用 IIFE 包一层，--raw 只输出结果方便重定向）
playwright-cli --raw eval '
  (() => {
    const items = [...document.querySelectorAll("section.HotItem")].slice(0, 10);
    return {
      date: new Date().toISOString(),
      items: items.map((el, index) => ({
        rank: index + 1,
        title: el.querySelector(".HotItem-title")?.innerText?.trim() || "",
        hot: el.querySelector(".HotItem-metrics")?.innerText?.replace(/\n.*$/s, "").trim() || ""
      }))
    };
  })()
' -s=zhihu-hot > zhihu-hot.json

# 6. 截图留档
playwright-cli screenshot -s=zhihu-hot --filename=zhihu-hot.png

# 7. 关闭会话，释放浏览器进程
playwright-cli close -s=zhihu-hot
```

> 实际测试发现：知乎在 `state-load` 后第一次访问 `/hot` 会先跳到 `signin?next=%2Fhot`，然后自动恢复登录态；执行一次 `reload` 即可稳定进入热榜页面。

这一段会消耗较多上下文——AI 要在试错中摸清登录态、页面结构、selector 名称和输出格式。成本可能在 30-50% 上下文窗口，具体取决于任务复杂度和模型能力。

### 4.4 第二段：提炼 Skill

第一次跑通后，不要关对话。让 AI 把走通的流程提炼成 Skill：

> “把上面走通的知乎热榜抓取流程提炼成 Skill，存到 `.claude/skills/zhihu-hot-rankings.md`。包括：登录态文件名、稳定的选择器、提取字段、输出格式、截图文件名。把试错过程删掉，只保留能复用的路径。”

AI 会生成一份类似这样的 `zhihu-hot-rankings.md`

```markdown
---
name: zhihu-hot-rankings
description: 抓取知乎热榜前 10 条标题和热度，输出 JSON 并截图。
allowed-tools: Bash(playwright-cli:*)
---

# 知乎热榜抓取

## 前置条件
- 登录态已保存到 `zhihu-auth.json`
- 运行环境已安装 playwright-cli

## 命令序列

```bash
# 1. 打开知乎热榜（复用同一 session 名，方便后续命令操作）
playwright-cli open https://www.zhihu.com/hot -s=zhihu-hot

# 2. 加载登录态，跳过登录流程
playwright-cli state-load zhihu-auth.json -s=zhihu-hot

# 3. 刷新一次，稳定进入热榜页面
playwright-cli reload -s=zhihu-hot

# 4. 读取快照，确认页面结构未变
playwright-cli snapshot -s=zhihu-hot --filename=zhihu-hot.yml

# 5. 提取前 10 条热榜数据并保存为 JSON
playwright-cli --raw eval '
  (() => {
    const items = [...document.querySelectorAll("section.HotItem")].slice(0, 10);
    return {
      date: new Date().toISOString(),
      items: items.map((el, index) => ({
        rank: index + 1,
        title: el.querySelector(".HotItem-title")?.innerText?.trim() || "",
        hot: el.querySelector(".HotItem-metrics")?.innerText?.replace(/\n.*$/s, "").trim() || ""
      }))
    };
  })()
' -s=zhihu-hot > zhihu-hot.json

# 6. 截图留档
playwright-cli screenshot -s=zhihu-hot --filename=zhihu-hot.png

# 7. 关闭会话
playwright-cli close -s=zhihu-hot
```

下一次再跑同样的任务，Claude Code 加载这个 Skill 后，只需要很少的上下文就能按上面的命令序列执行。成本通常降到第一次的 5-10%。

### 4.5 第三段：固化脚本

当这个任务需要每天跑、或者要接入 cron/CI 时，把 Skill 转成独立脚本，彻底把 AI 从运行时循环中拿掉。

你对 AI 说：

> “把上面的知乎热榜 Skill 转成一个独立 Bash 脚本。URL、选择器、输出格式都硬编码。加上日期目录、失败退出码、日志。”

AI 生成 `fetch-zhihu-hot.sh`：

```bash
#!/bin/bash
set -e

# 用时间戳生成唯一 session 名，避免和手动调试会话冲突
SESSION="zhihu-hot-$(date +%s)"

# 按日期时间创建输出目录，方便后续做趋势分析
OUTPUT_DIR="hot-rankings/$(date +%Y%m%d-%H%M%S)"
REPORT_FILE="$OUTPUT_DIR/hot.json"
mkdir -p "$OUTPUT_DIR"

# 1. 打开知乎热榜
playwright-cli open https://www.zhihu.com/hot -s=$SESSION

# 2. 加载已保存的登录态
playwright-cli state-load zhihu-auth.json -s=$SESSION

# 3. 知乎会先跳登录页再自动恢复，刷新一次确保进入热榜
playwright-cli reload -s=$SESSION

# 4. sanity check：确认已登录，未被重定向到登录页
CURRENT_URL=$(playwright-cli --raw eval "window.location.href" -s=$SESSION)
if echo "$CURRENT_URL" | grep -q "signin"; then
  echo "ERROR: Login expired. Please re-run the login flow and save zhihu-auth.json" >&2
  playwright-cli close -s=$SESSION
  exit 1
fi

# 5. 提取热榜数据（eval 顶层不能写 return/const，用 IIFE 包一层）
playwright-cli --raw eval '
  (() => {
    const items = [...document.querySelectorAll("section.HotItem")].slice(0, 10);
    return {
      date: new Date().toISOString(),
      items: items.map((el, index) => ({
        rank: index + 1,
        title: el.querySelector(".HotItem-title")?.innerText?.trim() || "",
        hot: el.querySelector(".HotItem-metrics")?.innerText?.replace(/\n.*$/s, "").trim() || ""
      }))
    };
  })()
' -s=$SESSION > "$REPORT_FILE"

# 6. 验证数据非空（文件非空且 items 数组长度大于 0）
if [ ! -s "$REPORT_FILE" ] || [ "$(jq '.items | length' "$REPORT_FILE")" = "0" ]; then
  echo "ERROR: No hot items extracted. Page structure may have changed." >&2
  playwright-cli screenshot -s=$SESSION --filename="$OUTPUT_DIR/failure.png"
  playwright-cli close -s=$SESSION
  exit 1
fi

# 7. 截图留档并关闭会话
playwright-cli screenshot -s=$SESSION --filename="$OUTPUT_DIR/hot.png"
playwright-cli close -s=$SESSION

echo "Saved hot ranking to $REPORT_FILE"
```

脚本运行时不调用任何 LLM，Token 成本归零。

### 4.6 第三段的代价与边界

不是每个任务都适合推到第三段。固化脚本有灵活性、可解释性和机会成本三个主要代价：

- **失去灵活性**：网站 HTML 一改，脚本就可能静默失败。Skill 版本还能尝试自适应，脚本不会。
- **失去可解释性**：出问题时没有 AI 可以问“你刚才试了什么？”，需要靠日志和截图复盘。
- **错过新机会**：网站可能新增了更快的 API 或更稳定的选择器，脚本永远不会主动发现。

对应的缓解措施：

- 脚本顶部加页面检测，比如检查页面标题或关键元素是否存在，对不上预期就 exit 非零。
- 每条命令的退出码和输出都打到日志文件，方便后续诊断。
- 隔一段重跑一次第一段探索，确认当前方法还是不是最优。

经验法则：

- **UI 频繁变动的网站**：停在第二段（Skill），让 AI 保留一定的自适应能力。
- **结构稳定、每天要跑 50 次以上的任务**：推到第三段（脚本），换取 0 Token。
- **需要处理每轮变化的输入**（如不同商品的 URL、每篇文章不同的图片）：第二段和第三段混合使用，固定部分写脚本，变化部分保留 AI 决策。

### 4.7 三段式降本效果

| 阶段       | 方式                   | Token 消耗       | 产出             |
| ---------- | ---------------------- | ---------------- | ---------------- |
| AI 探索    | 自然语言驱动，走通流程 | 30-50% 上下文    | 走通的命令序列   |
| 提炼 Skill | 加载 Skill 后执行      | 3-7% 上下文      | Skill 文件       |
| 脚本执行   | 纯脚本，无 AI 参与     | **无 LLM Token** | 稳定运行的自动化 |

核心逻辑：任务稳定后把 AI 从循环里拿掉。最贵的部分是 AI 推理，固化成脚本后 LLM Token 成本归零。

---

## 五、最佳实践与常见陷阱

### 5.1 Skill 要在第三次成功后重蒸馏

第一版 Skill 通常会漏掉一些边界情况：某个按钮只在特定状态下出现、某个等待时间在网络慢时不够、某个日期格式之前没遇到。第三次跑完后，AI 已经踩过足够多的边界，这时再重新生成 Skill 最稳。

### 5.2 登录态会过期，要加哨兵

大多数网站的登录态有效期是 7-30 天。脚本应该在开始抓取前访问一个需要登录的页面，检查关键登录态元素是否存在，不存在就 exit 非零并通知人工处理。

### 5.3 不要默认并行多个会话

Playwright CLI 的 daemon 在并行调用之间隔离不够干净，容易出现 Cookie 串、下载覆盖等问题。需要并行时，建议开多个独立工作目录，各自使用不同的 `--persistent` profile。

### 5.4 第三段脚本要留诊断入口

纯脚本跑 0 Token，但出问题时需要快速定位。建议：

- 每条命令的退出码和输出写入日志。
- 失败时自动截图保存到失败目录。
- 保留把日志 + 脚本一起扔给 AI 诊断的能力。

### 5.5 AI 是发现工具，不是运行时

最核心的原则：任务一旦稳定，就把 AI 从循环里拿掉。第一次用 AI 探索，第二次用 AI 提炼 Skill，第三次决定是继续用 Skill 还是固化成脚本。不要让 AI 反复解决已经解决的问题。

---

## 六、总结

Playwright CLI 把浏览器自动化能力从 MCP 的“每步返回完整页面状态”模式，转变为“按需读取、磁盘中转”的 Shell 命令模式，从而在长会话和多步任务中显著降低 Token 消耗。

核心使用路径可以概括为三段式：

1. **AI 探索**：用自然语言让 AI 走通流程，允许试错，目标是拿到可复用的命令序列。
2. **提炼 Skill**：把走通的流程写成 `.claude/skills/` 下的 Skill 文件，固定 URL、选择器、输出格式和失败处理。
3. **固化脚本**：对结构稳定、重复执行的任务，转成独立 Bash 脚本，彻底把 AI 从运行时循环中拿掉，实现 0 LLM Token。

在工具选型上：

- Claude Code / Cursor 内嵌自动化优先选 **Playwright CLI**（Token 最低）。
- 需要复用已有 Chrome 实例、做性能诊断或 Electron 自动化时，选 **Chrome DevTools MCP**。
- 构建独立 Agent 应用、需要多模型切换或 LangChain 编排时，选 **Browser Use**。

最后记住一条原则：**AI 是发现工具，不是运行时**。任务一旦稳定，就把可复用的部分沉淀成 Skill 或脚本，不要让 AI 反复解决已经解决的问题。

## 七、参考

- [Playwright CLI 官方文档](https://playwright.cn/agent-cli/introduction)
- [Playwright MCP 官方文档](https://playwright.cn/mcp/introduction)
- [Playwright CLI 与 MCP：两种给 AI 看世界的方式](https://yangzh.cn/posts/posts/playwright-cli-vs-mcp.html)
- [Playwright CLI + Skill 三段式：把 AI 浏览器自动化做到 0 Token](https://www.heyuan110.com/zh/posts/ai/2026-04-18-playwright-cli-skill-zero-token-automation/)
- [Playwright CLI 从入门到实战](https://juejin.cn/post/7631473695152619546)
- [基于 playwright-cli + Skills 实现 UI 自动化测试实战](https://zhuanlan.zhihu.com/p/2029618492178011224)
- [Claude Code MCP Tool Search 官方介绍](https://www.anthropic.com/engineering/advanced-tool-use)
- [Playwright MCP 和 Chrome DevTools MCP 区别](https://kimigao.com/blog/playwright-mcp-vs-chrome-devtools-mcp/)
- [MorphLLM Playwright 自动化对比](https://www.morphllm.com/playwright-mcp)
- [TestQuality/Currents.dev MCP 架构](https://testquality.com/playwright-test-agents-mcp-architecture-2026/)
- [Bug0 CLI vs MCP 对比](https://bug0.com/blog/playwright-cli-vs-playwright-mcp-ai-browser-testing-2026)
- [TestDino CLI vs MCP](https://testdino.com/blog/playwright-cli-vs-mcp)
- [ytyng.com 自动化工具对比](https://www.ytyng.com/en/blog/ai-browser-automation-tools-comparison-2026)
